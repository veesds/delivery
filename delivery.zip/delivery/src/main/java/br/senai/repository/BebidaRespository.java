package br.senai.repository;

import br.senai.model.Bebida;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BebidaRespository extends JpaRepository<Bebida, Long> {
    public Bebida findByMarca(String marca);
    public Bebida findByDescricao(String descricao);
    public Bebida findByPreco(String preco);
    public Bebida findByDescricaoAndPreco(String descricao, String preco);
    public Bebida findByMarcaLike(String marca);
}
