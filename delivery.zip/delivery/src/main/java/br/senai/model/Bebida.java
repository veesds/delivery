package br.senai.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;
@Entity(name="bebida")
public class Bebida {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Size(max = 100)
    private String marca;

    @Size(max = 100)
    private String preco;

    @Size(max=25)
    private String descricao;
//    private List<Bebida> bebidas;

    public void setId(Long id) {
        this.id = id;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getPreco() {
        return preco;
    }
    public void setPreco(String preco) {
        this.preco = preco;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Bebida{" +
                "id=" + id +
                ", marca='" + marca + '\'' +
                ", preco='" + preco + '\'' +
                ", descricao='" + descricao + '\'' +
//                ", bebidas=" + bebidas +
                '}';
    }
}
