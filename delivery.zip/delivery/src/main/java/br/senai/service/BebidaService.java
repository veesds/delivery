package br.senai.service;

import br.senai.model.Bebida;

import java.util.List;

public interface BebidaService {
    public List<Bebida> findAll();
    public Bebida findById(Long id);

    Bebida findByMarca
            (String marca);

    public Bebida save(Bebida bebida);
    public void  deleteById(Long id);
}
