package br.senai.service;

import br.senai.model.Bebida;
import br.senai.repository.BebidaRespository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public  class BebidaServiceImpl implements BebidaService {
    @Autowired
    BebidaRespository bebidaRespository;

    @Override
    public List<Bebida> findAll(){
        return bebidaRespository.findAll();
    }
    @Override
    public Bebida findById(Long id){
        Optional listBebida = bebidaRespository.findById(id);
        if (listBebida != null){
            return (Bebida) listBebida.get();
        } else {
            return  new Bebida();
        }

    }

    @Override
    public Bebida findByMarca(String marca) {
        return bebidaRespository.findByMarca(marca);
    }

    @Override
    public Bebida save(Bebida bebida) {
        try {
            return bebidaRespository.save(bebida);
        } catch (Exception e){
            throw e;
        }
    }
    @Override
    public void deleteById(Long id){
        try {
            bebidaRespository.deleteById(id);
        }catch (Exception e){
            throw e;
        }
    }
}
