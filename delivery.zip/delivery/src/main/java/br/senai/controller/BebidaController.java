package br.senai.controller;

import br.senai.model.Bebida;
import br.senai.model.Cliente;
import br.senai.service.BebidaServiceImpl;
import br.senai.service.ClienteServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
@Controller
public class BebidaController {
    @Autowired
    BebidaServiceImpl bebidaService;

    @GetMapping("/bebida/list")
    public String findAll(Model model) {
        model.addAttribute("bebida", bebidaService.findAll());
        return "bebida/list";
    }

    @GetMapping("/bebida/add")
    public String add(Model model) {
        model.addAttribute("bebida", new Bebida());
        return "bebida/add";
    }

    @GetMapping("/bebida/edit/{id}")
    public String edit(Model model, @PathVariable long id) {
        model.addAttribute("bebida", bebidaService.findById(id));
        return "bebida/edit";
    }

    @PostMapping("/Bebida/search")
    public String findByMarca(Bebida bebida, Model model) {
        try {
            System.out.println("Bebida::: " + bebida);
            model.addAttribute("bebida", bebidaService.findByMarca(bebida.getMarca()));
            model.addAttribute("bebidaPesquisa", new Bebida());
            return "bebida/list";
        }catch (Exception e){
            return "bebida/list";
        }
    }
    @GetMapping("/bebida/delete/{id}")
    public String delete(@PathVariable long id) {
        try {
            bebidaService.deleteById(id);
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
        return "redirect:/bebida/list";
    }
}

